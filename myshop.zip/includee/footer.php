<div  class="bg-info p-0 text-center">
    <p>
        All right reserved 0- Designed by Anjali-2023
    </p>
</div>
